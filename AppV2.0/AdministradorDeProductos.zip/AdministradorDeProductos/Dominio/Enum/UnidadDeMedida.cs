﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdministradorDeProductos.Enum
{
    public enum UnidadDeMedida
    {
        Unidad,
        Lt,
        Ml,
        Lbr,
        Gr,
        Kg,
    }
}
